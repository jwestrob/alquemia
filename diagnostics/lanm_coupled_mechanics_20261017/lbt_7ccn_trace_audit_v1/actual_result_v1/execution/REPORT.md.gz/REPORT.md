# Saved step92-to172 mechanics audit

Status: **complete**. Zero molecular calls; no optimization.

All81 saved states and80 transitions admitted under frozen replay tolerances. Exact raw component-gradient closure retained.

| Steps | MACE work | ALPB work | Total work | RMS force before → after | Trust-scaled steps | History resets |
|---|---:|---:|---:|---:|---:|---:|
| 92–112 | 5.954840 | -13.812711 | -7.857871 | 1.086248 → 1.022402 | 1 | 0 |
| 112–132 | -1.628999 | -1.436215 | -3.065214 | 1.022402 → 1.943856 | 0 | 0 |
| 132–152 | -1.108651 | -0.918697 | -2.027348 | 1.943856 → 0.531560 | 1 | 0 |
| 152–172 | 2.091620 | -4.726851 | -2.635231 | 0.531560 → 1.045572 | 0 | 0 |
| 92–172 | 5.308810 | -20.894474 | -15.585663 | 1.086248 → 1.045572 | 2 | 0 |

Work: kcal/mol. Force: kcal/mol/Å. Windows are fixed before execution.

## Native solvent work components

| Steps | Gelec | Ghb | Gsasa | Gshift |
|---|---:|---:|---:|---:|
| 92–112 | -13.917132 | 0.940982 | -0.836562 | 0.000000 |
| 112–132 | -1.157987 | -0.014578 | -0.263650 | 0.000000 |
| 132–152 | -0.869798 | 0.093171 | -0.142070 | 0.000000 |
| 152–172 | -4.213826 | -0.403662 | -0.109363 | 0.000000 |
| 92–172 | -20.158742 | 0.615913 | -1.351644 | 0.000000 |

Full per-step component norms, dot products, projections, H0 scales, curvature and replay residuals are in RESULT.json. Initial/terminal atom and residue attribution files include the metal separately.

Passing replay excludes the tested bookkeeping inconsistencies; it does not establish physical accuracy. Continued lowering, solvent dominance, trust scaling or nonconvergence alone do not identify a defective interaction. No further search or reference is released.

The observed net lowering trades increased vacuum MACE energy for lower solvent energy. The next mechanics decision should address this component balance and the measured direction/scaling behavior, rather than assume another step allowance or a bookkeeping repair is needed. Solvent lowering alone is not evidence that solvent is wrong.
